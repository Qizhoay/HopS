import os.path as osp

import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.cuda.amp import GradScaler, autocast

from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.metrics import compute_accuracy
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler

from clip import clip
from clip.simple_tokenizer import SimpleTokenizer as _Tokenizer

import torch.nn.functional as F
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from torch.distributions.kl import kl_divergence
from torch.distributions import Categorical



_tokenizer = _Tokenizer()

def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    model = clip.build_model(state_dict or model.state_dict())

    return model


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        x = prompts + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x).type(self.dtype)
        x = x[torch.arange(x.shape[0]), tokenized_prompts.argmax(dim=-1)] @ self.text_projection

        return x


class PromptLearner(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        n_cls = len(classnames)
        n_ctx = cfg.TRAINER.HOPS.N_CTX
        ctx_init = cfg.TRAINER.HOPS.CTX_INIT
        dtype = clip_model.dtype
        ctx_dim = clip_model.ln_final.weight.shape[0]
        clip_imsize = clip_model.visual.input_resolution
        cfg_imsize = cfg.INPUT.SIZE[0]
        assert cfg_imsize == clip_imsize, f"cfg_imsize ({cfg_imsize}) must equal to clip_imsize ({clip_imsize})"

        if ctx_init:
            # use given words to initialize context vectors
            ctx_init = ctx_init.replace("_", " ")
            n_ctx = len(ctx_init.split(" "))
            prompt = clip.tokenize(ctx_init)
            with torch.no_grad():
                embedding = clip_model.token_embedding(prompt).type(dtype)
            ctx_vectors = embedding[0, 1 : 1 + n_ctx, :]
            prompt_prefix = ctx_init

        else:
            # random initialization
            if cfg.TRAINER.HOPS.CSC:
                print("Initializing class-specific contexts")
                ctx_vectors = torch.empty(n_cls, n_ctx, ctx_dim, dtype=dtype)
            else:
                print("Initializing a generic context")
                ctx_vectors = torch.empty(n_ctx, ctx_dim, dtype=dtype)
            nn.init.normal_(ctx_vectors, std=0.02)
            prompt_prefix = " ".join(["X"] * n_ctx)

        print(f'Initial context: "{prompt_prefix}"')
        print(f"Number of context words (tokens): {n_ctx}")

        self.ctx = nn.Parameter(ctx_vectors)  # to be optimized

        classnames = [name.replace("_", " ") for name in classnames]
        name_lens = [len(_tokenizer.encode(name)) for name in classnames]
        prompts = [prompt_prefix + " " + name + "." for name in classnames]

        tokenized_prompts = torch.cat([clip.tokenize(p) for p in prompts])
        print(f'prompts{len(prompts)}\n{prompts}')
        # print(f'tokenized_prompts{tokenized_prompts.size()}\n{tokenized_prompts}')
        
        with torch.no_grad():
            embedding = clip_model.token_embedding(tokenized_prompts).type(dtype)

        # These token vectors will be saved when in save_model(),
        # but they should be ignored in load_model() as we want to use
        # those computed using the current class names
        self.register_buffer("token_prefix", embedding[:, :1, :])  # SOS
        self.register_buffer("token_suffix", embedding[:, 1 + n_ctx :, :])  # CLS, EOS

        self.n_cls = n_cls
        self.n_ctx = n_ctx
        self.tokenized_prompts = tokenized_prompts  # torch.Tensor
        self.name_lens = name_lens
        self.class_token_position = cfg.TRAINER.HOPS.CLASS_TOKEN_POSITION

    def forward(self):
        ctx = self.ctx
        if ctx.dim() == 2:
            ctx = ctx.unsqueeze(0).expand(self.n_cls, -1, -1)

        prefix = self.token_prefix
        suffix = self.token_suffix

        if self.class_token_position == "end":
            prompts = torch.cat(
                [
                    prefix,  # (n_cls, 1, dim)
                    ctx,     # (n_cls, n_ctx, dim)
                    suffix,  # (n_cls, *, dim)
                ],
                dim=1,
            )

        elif self.class_token_position == "middle":
            half_n_ctx = self.n_ctx // 2
            prompts = []
            for i in range(self.n_cls):
                name_len = self.name_lens[i]
                prefix_i = prefix[i : i + 1, :, :]
                class_i = suffix[i : i + 1, :name_len, :]
                suffix_i = suffix[i : i + 1, name_len:, :]
                ctx_i_half1 = ctx[i : i + 1, :half_n_ctx, :]
                ctx_i_half2 = ctx[i : i + 1, half_n_ctx:, :]
                prompt = torch.cat(
                    [
                        prefix_i,     # (1, 1, dim)
                        ctx_i_half1,  # (1, n_ctx//2, dim)
                        class_i,      # (1, name_len, dim)
                        ctx_i_half2,  # (1, n_ctx//2, dim)
                        suffix_i,     # (1, *, dim)
                    ],
                    dim=1,
                )
                prompts.append(prompt)
            prompts = torch.cat(prompts, dim=0)

        elif self.class_token_position == "front":
            prompts = []
            for i in range(self.n_cls):
                name_len = self.name_lens[i]
                prefix_i = prefix[i : i + 1, :, :]
                class_i = suffix[i : i + 1, :name_len, :]
                suffix_i = suffix[i : i + 1, name_len:, :]
                ctx_i = ctx[i : i + 1, :, :]
                prompt = torch.cat(
                    [
                        prefix_i,  # (1, 1, dim)
                        class_i,   # (1, name_len, dim)
                        ctx_i,     # (1, n_ctx, dim)
                        suffix_i,  # (1, *, dim)
                    ],
                    dim=1,
                )
                prompts.append(prompt)
            prompts = torch.cat(prompts, dim=0)

        else:
            raise ValueError

        return prompts

class CustomCLIP(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        self.prompt_learner = PromptLearner(cfg, classnames, clip_model)
        self.tokenized_prompts = self.prompt_learner.tokenized_prompts
        self.image_encoder = clip_model.visual
        self.text_encoder = TextEncoder(clip_model)
        self.logit_scale = clip_model.logit_scale
        self.dtype = clip_model.dtype
        self.classnames = classnames
        self.clip_model = clip_model
    
    def forward(self, image):
        image_features = self.image_encoder(image.type(self.dtype))
        prompts = self.prompt_learner() # ([100, 77, 512])
        tokenized_prompts = self.tokenized_prompts # ([100, 77])
        # print(f'prompts{prompts.size()}tokenized_prompts{tokenized_prompts.size()}')
        text_features = self.text_encoder(prompts, tokenized_prompts) # ([100, 1024])
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)
        # print(f'image_features{image_features.size()}text_features{text_features.size()}')
        # ([32, 1024])([100, 1024]) ————————> ([32, 100])
        logit_scale = self.logit_scale.exp()
        logits = logit_scale * image_features @ text_features.t()
        return logits, image_features


@TRAINER_REGISTRY.register()
class HOPS(TrainerX):

    def check_cfg(self, cfg):
        assert cfg.TRAINER.HOPS.PREC in ["fp16", "fp32", "amp"]

    def build_model(self):
        cfg = self.cfg
        classname_set = self.dm.dataset.classnames
        print(f'classname_set{len(classname_set)}\n{classname_set}')

        # 使用集合去重
        classnames = set(item for sublist in classname_set for item in sublist)
        n_cls = len(classnames)
        print(f'classnames{len(classnames)}\n{classnames}')

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)
        
        if cfg.TRAINER.HOPS.PREC == "fp32" or cfg.TRAINER.HOPS.PREC == "amp":
            # CLIP's default precision is fp16
            clip_model.float()

        print("Building custom CLIP")
        self.model = CustomCLIP(cfg, classnames, clip_model)

        print("Turning off gradients in both the image and the text encoder")
        for name, param in self.model.named_parameters():
            if "prompt_learner" not in name:
                param.requires_grad_(False)

        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model.prompt_learner, cfg.MODEL.INIT_WEIGHTS)

        self.model.to(self.device)
        # 初始化全局 feature 和 label bank（先占位）
        num_samples = len(self.dm.dataset.train_x)
        feat_dim = self.model.image_encoder.output_dim
        num_classes = len(self.model.classnames)

        self.feature_bank = torch.zeros(num_samples, feat_dim).to(self.device)
        self.label_bank = torch.zeros(num_samples, num_classes).to(self.device)
        # NOTE: only give prompt_learner to the optimizer
        self.optim = build_optimizer(self.model.prompt_learner, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model("prompt_learner", self.model.prompt_learner, self.optim, self.sched)

        self.scaler = GradScaler() if cfg.TRAINER.HOPS.PREC == "amp" else None

        # Note that multi-gpu training could be slow because CLIP's size is
        # big, which slows down the copy operation in DataParallel
        device_count = torch.cuda.device_count()
        if device_count > 1:
            print(f"Multiple GPUs detected (n_gpus={device_count}), use all of them!")
            self.model = nn.DataParallel(self.model)

    def forward_backward(self, batch):
        image, label, true, index = self.parse_batch_train(batch)
        B = image.size(0)
        num_classes = self.num_classes
        cfg = self.cfg
        prec = cfg.TRAINER.HOPS.PREC

        if prec == "amp":
            raise NotImplementedError("请先用 fp32 测试该一致性筛除版本")

        logits, image_features = self.model(image)
        # print(f'image_features{image_features.size()}') # ([32, 1024])
        # print(f'logits{logits.size()}') # ([32, 100])
        probs = F.softmax(logits, dim=1)  # 模型 softmax 概率 [B, C]

        # === Step 1: 初始候选集合来自偏标记 ===
        candidate_mask = F.one_hot(label, num_classes=num_classes).sum(dim=1).clamp(0, 1).float()  # [B, C]

        # === Step 2: 保存特征/标签进全局 bank ===
        self.feature_bank[index] = image_features.detach().float()
        self.label_bank[index] = candidate_mask.detach().float()
        global_features = self.feature_bank
        global_labels = self.label_bank
        # print(f'global_features{global_features.size()}global_labels{global_labels.size()}')
        # global_featurestorch.Size([1600, 1024])global_labelstorch.Size([1600, 100])
        
        # === Step 3: 构建image-label cost matrix [1600 * 100] ===
        # 每个样本经过image_encoder
        ori_image = global_features # [1600 * 1024]
        # 每个标签经过image_encoder
        ori_label = self.model.text_encoder(self.model.prompt_learner(), self.model.tokenized_prompts) # ([100, 1024])
        # ori_sim_imlab: 相似度矩阵[1600, 100]
        epsilon = 1e-8
        ori_image = ori_image.float() / (ori_image.float().norm(dim=-1, keepdim=True) + epsilon)
        ori_label = ori_label.float() / (ori_label.float().norm(dim=-1, keepdim=True) + epsilon)
        ori_scale = self.model.logit_scale.exp()
        ori_sim_imlab = ori_scale * ori_image @ ori_label.t()
        ori_sim_imlab = F.softmax(ori_sim_imlab, dim=1)
        # ori_cost_matrix: 代价矩阵[1600, 100]
        ori_cost_matrix = (1 - ori_sim_imlab) * global_labels + (1 - global_labels) * 1e9  # ([1600, 100])
        # print(f'ori_cost_matrix[min: {ori_cost_matrix.min()}, max: {ori_cost_matrix.max()}]')

        # === Step 4.5: 使用最优传输（Sinkhorn）计算传输计划（增强监督） ===
        with torch.no_grad():
            # 当前 batch 的 cost 子矩阵（根据 index 提取）
            cost_submatrix = ori_cost_matrix[index]  # [32, 100]
            # 构造边缘分布
            r = torch.ones(B, device=self.device) / B  # 图像分布 [32]
            c = candidate_mask.sum(dim=0) / candidate_mask.sum()

            def sinkhorn_knopp(cost, r, c, epsilon=0.05, max_iter=50):
                K = torch.exp(-cost / epsilon) + 1e-8  # 避免除0
                u = torch.ones_like(r, dtype = K.dtype)
                v = torch.ones_like(c, dtype = K.dtype)
                for _ in range(max_iter):
                    u = r / (K @ v)
                    v = c / (K.T @ u)
                P = torch.diag(u) @ K @ torch.diag(v)
                return P
            ot_plan = sinkhorn_knopp(cost_submatrix, r, c)  # ([32, 100])
            ot_pred = (ot_plan * candidate_mask).argmax(dim=1)  # [B]

        # === Step 4: KNN 一致性筛除 ===
        sim = image_features.float() @ global_features.t().float()  # [B, N]
        knn_k = 20
        τ = 0.4
        _, knn_idx = torch.topk(sim, k=knn_k, dim=1)
        knn_labels = global_labels[knn_idx]  # [B, knn_k, C]
        votes = knn_labels.sum(dim=1)  # [B, C]
        knn_mask = (votes / knn_k) >= τ  # [B, C]
        filtered_mask = candidate_mask * knn_mask.float()
        
        # 防止标签被清空
        empty_mask = (filtered_mask.sum(dim=1) == 0).unsqueeze(1)
        filtered_mask = torch.where(empty_mask, candidate_mask, filtered_mask)

        # === Step 5: 筛后的标签标签构建掩码 选取概率的最大值 ===
        probs_in_candidates = probs * filtered_mask  # [B, C]
        max_probs, max_idx = probs_in_candidates.max(dim=1)  # 每行最大值

        # === 标签准确率 ===
        # === 计算重合率（准确率）
        ot_acc = (ot_pred == true).float().mean().item()
        max_acc = (max_idx == true).float().mean().item()
        ot_max = (ot_pred == max_idx).float().mean().item()

        mask = (ot_pred == max_idx)                     # 找出 ot_pred 和 max_idx 相等的位置
        overlap = (ot_pred[mask] == true[mask])         # 在这些位置中，ot_pred 是否也等于 true
        comb_acc = overlap.float().mean().item() 
        print(f"ot_acc = {ot_acc:.2f} , max_acc = {max_acc:.2f}, ot_max = {ot_max:.2f}, ot_max_acc = {comb_acc:.2f}")
        
        # === Step 6: 交叉熵损失 ===
        loss_vo = F.cross_entropy(logits, max_idx)
        loss_ot = F.cross_entropy(logits, ot_pred)
        loss = loss_ot + loss_vo
        # loss = loss_vo
        loss = loss_ot

        # # 2. cc_loss
        # output = self.model(image)
        # probs = F.softmax(output, dim=1)
        # candidate_mask[candidate_mask > 0]  = 1 # [0,1,1,0,1,0]
        # loss = - torch.log((probs * candidate_mask).sum(dim=1)).mean()

        self.model_backward_and_update(loss)

        # === Step 7: 返回训练指标 ===
        loss_summary = {
            "loss": loss.item(),
            "acc": compute_accuracy(probs, true)[0].item(),
        }

        if (self.batch_idx + 1) == self.num_batches:
            self.update_lr()

        return loss_summary


    def parse_batch_train(self, batch):
        input = batch["img"]
        label = batch["label"]
        index = batch["index"]
        if isinstance(label,list):
            label = torch.stack(label, dim=1)
        input = input.to(self.device)
        label = label.to(self.device)
        # print(f'label{len(label)}\n{label}')
        true = batch["label"][0].to(self.device)
        # print(f'true{len(true)}\n{true}')
        return input, label, true, index

    def load_model(self, directory, epoch=None):
        if not directory:
            print("Note that load_model() is skipped as no pretrained model is given")
            return

        names = self.get_model_names()

        # By default, the best model is loaded
        model_file = "model-best.pth.tar"

        if epoch is not None:
            model_file = "model.pth.tar-" + str(epoch)

        for name in names:
            model_path = osp.join(directory, name, model_file)

            if not osp.exists(model_path):
                raise FileNotFoundError('Model not found at "{}"'.format(model_path))

            checkpoint = load_checkpoint(model_path)
            state_dict = checkpoint["state_dict"]
            epoch = checkpoint["epoch"]

            # Ignore fixed token vectors
            if "token_prefix" in state_dict:
                del state_dict["token_prefix"]

            if "token_suffix" in state_dict:
                del state_dict["token_suffix"]

            print("Loading weights to {} " 'from "{}" (epoch = {})'.format(name, model_path, epoch))
            # set strict=False
            self._models[name].load_state_dict(state_dict, strict=False)
