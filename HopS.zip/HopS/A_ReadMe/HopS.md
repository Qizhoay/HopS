## How to Run
The executable scripts are provided in the scripts/hops/ directory. Each script requires six input arguments. `DATASET` takes as input a dataset name, like `caltech101`. The valid names are the files' names in `HopS/configs/datasets/`. `CFG` means which config file to use, such as `rn50`, `rn50_b16` or `rn50_b64` (see `HopS/configs/trainers/HopS/`). 
1. for rand-confusion: 
|–– main.sh ()
2. for insd-confusion: 
|–– main_insd_clip_prosim.sh
|–– main_insd_rn18_prosim.sh
|–– main_insd_rn50_prosim.sh

Make sure you change the path in `DATA` and run the commands under the main directory `HopS/`.

Below we provide examples on how to run HopS and CoOp on Caltech101 with 1 confusion labels or with clean label. The complete running command can be found in the corresponding file (see `/Confusion` and `/Clean`).

## HopS
conda env create -f HopS_env.yaml
conda activate HopS
cd .../HopS

**Rand**:
- uni: `bash scripts/hops/main.sh caltech101_pl rn50 end 16 16 False 1`
- cls: `bash scripts/hops/main.sh caltech101_pl rn50 end 16 16 True 1`

**Insd-r18**:
- uni: `bash scripts/hops/main_insd_rn18_prosim.sh caltech101_pl rn50 end 16 16 False 2`
- cls: `bash scripts/hops/main_insd_rn18_prosim.sh caltech101_pl rn50 end 16 16 True 2`

**Insd-r50**:
- uni: `bash scripts/hops/main_insd_rn50_prosim.sh caltech101_pl rn50 end 16 16 False 2`
- cls: `bash scripts/hops/main_insd_rn50_prosim.sh caltech101_pl rn50 end 16 16 True 2`

**Insd-clip**:
- uni: `bash scripts/hops/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 True 1`
- cls: `bash scripts/hops/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 True 1`

## CoOpIns
**Rand**:
- uni: `bash scripts/coopins/main.sh caltech101_pl rn50 end 16 16 False 1`
- cls: `bash scripts/coopins/main.sh caltech101_pl rn50 end 16 16 True 1`

**Insd-r18**:
- uni: `bash scripts/coopins/main_insd_rn18_prosim.sh caltech101_pl rn50 end 16 16 False 2`
- cls: `bash scripts/coopins/main_insd_rn18_prosim.sh caltech101_pl rn50 end 16 16 True 2`

**Insd-r50**:
- uni: `bash scripts/coopins/main_insd_rn50_prosim.sh caltech101_pl rn50 end 16 16 False 2`
- cls: `bash scripts/coopins/main_insd_rn50_prosim.sh caltech101_pl rn50 end 16 16 True 2`

**Insd-clip**:
- uni: `bash scripts/coopins/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 True 1`
- cls: `bash scripts/coopins/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 True 1`

## CoOp
- uni: `bash scripts/coop/main.sh caltech101 rn50 end 16 16 False`
- cls: `bash scripts/coop/main.sh caltech101 rn50 end 16 16 True`

## Zero-shot CLIP
- `bash scripts/coop/zeroshot.sh caltech101 rn50`