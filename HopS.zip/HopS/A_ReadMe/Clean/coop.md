# uni-coop
bash scripts/coop/main.sh caltech101 rn50 end 16 16 False
bash scripts/coop/main.sh dtd rn50 end 16 16 False
bash scripts/coop/main.sh eurosat rn50 end 16 16 False

bash scripts/coop/main.sh fgvc_aircraft rn50 end 16 16 False
bash scripts/coop/main.sh food-101 rn50 end 16 16 False
bash scripts/coop/main.sh oxford_flowers rn50 end 16 16 False

bash scripts/coop/main.sh oxford_pets rn50 end 16 16 False
bash scripts/coop/main.sh ucf101 rn50 end 16 16 False

# cls-coop
bash scripts/coop/main.sh caltech101 rn50 end 16 16 True
bash scripts/coop/main.sh dtd rn50 end 16 16 True
bash scripts/coop/main.sh eurosat rn50 end 16 16 True

bash scripts/coop/main.sh fgvc_aircraft rn50 end 16 16 True
bash scripts/coop/main.sh food-101 rn50 end 16 16 True
bash scripts/coop/main.sh oxford_flowers rn50 end 16 16 True

bash scripts/coop/main.sh oxford_pets rn50 end 16 16 True
bash scripts/coop/main.sh ucf101 rn50 end 16 16 True