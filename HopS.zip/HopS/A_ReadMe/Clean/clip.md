bash scripts/coop/zeroshot.sh caltech101 rn50
bash scripts/coop/zeroshot.sh dtd rn50
bash scripts/coop/zeroshot.sh eurosat rn50
bash scripts/coop/zeroshot.sh fgvc_aircraft rn50
bash scripts/coop/zeroshot.sh food-101 rn50
bash scripts/coop/zeroshot.sh oxford_flowers rn50
bash scripts/coop/zeroshot.sh oxford_pets rn50
bash scripts/coop/zeroshot.sh ucf101 rn50