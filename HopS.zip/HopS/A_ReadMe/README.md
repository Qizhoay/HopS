# Holistic Optimal Label Selection for Robust Prompt Learning under Partial Labels

This repo contains the codebase of a series of research projects focused on adapting vision-language models like [CLIP](https://arxiv.org/abs/2103.00020) to downstream datasets via prompt learning like [CoOp](https://arxiv.org/abs/2109.01134) in partial label supervision.

## How to Install
This code is built on top of the awesome toolbox [Dassl.pytorch](https://github.com/KaiyangZhou/Dassl.pytorch) so you need to install the `dassl` environment first. Simply follow the instructions described [here](https://github.com/KaiyangZhou/Dassl.pytorch#installation) to install `dassl` as well as PyTorch. After that, run `pip install -r requirements.txt` under `HopS/` to install a few more packages required by [CLIP](https://github.com/openai/CLIP) (this should be done when `dassl` is activated). Then, you are ready to go.

Follow [DATASETS.md](DATASETS.md) to install the datasets.

# How to generate the partial label version.
The generation function of confusion is in .../HopS/datasets/add_candy.py
Each dataset corresponds to five generated files as:
datasets/
|–– {dataname}_insd_clip_prosim.py    (insd confusion from CLIP-RN50)
|–– {dataname}_insd_rn50_prosim.py    (insd confusion from ResNet-50)
|–– {dataname}_insd_rn18_prosim.py    (insd confusion from ResNet-18)
|–– {dataname}_pl.py                  (rand confusion)
|–– {dataname}.py                     (clean)

## How to Run
See `HopS.md`, the detailed instructions on how to run the code to reproduce the results.

## Citation
Our implementation process is based on CoOp's code.

@article{zhou2022coop,
    title={Learning to Prompt for Vision-Language Models},
    author={Zhou, Kaiyang and Yang, Jingkang and Loy, Chen Change and Liu, Ziwei},
    journal={International Journal of Computer Vision (IJCV)},
    year={2022}
}
