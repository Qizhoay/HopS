bash scripts/hops/main_insd_rn50_prosim.sh caltech101_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh dtd_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh eurosat_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh FGVCAircraft_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh food101_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh oxford_flowers_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh oxford_pets_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh ucf101_pl rn50 end 16 16 True 4insd_ce_loss_rn50_prosim

bash scripts/hops/main_insd_rn50_prosim.sh caltech101_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh dtd_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh eurosat_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh FGVCAircraft_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh food101_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh oxford_flowers_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh oxford_pets_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim
bash scripts/hops/main_insd_rn50_prosim.sh ucf101_pl rn50 end 16 16 False 4insd_ce_loss_rn50_prosim

