conda activate YqCoop
cd /data1/zhaoyaqi/Yq23/250303_Coop/CoOp-final
# Now: 第一行
bash scripts/hops/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh dtd_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh dtd_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh eurosat_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh eurosat_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh FGVCAircraft_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh FGVCAircraft_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh food101_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh food101_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh oxford_flowers_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh oxford_flowers_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh oxford_pets_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh oxford_pets_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim

bash scripts/hops/main_insd_clip_prosim.sh ucf101_pl rn50 end 16 16 False 3insd_ce_loss_cliprn50_prosim
bash scripts/hops/main_insd_clip_prosim.sh ucf101_pl rn50 end 16 16 True 3insd_ce_loss_cliprn50_prosim

