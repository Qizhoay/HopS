# Now:  
# caltech101_pl dtd_pl eurosat_pl FGVCAircraft_pl 
# food101_pl oxford_flowers_pl oxford_pets_pl ucf101_pl
bash scripts/coopins/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh caltech101_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh dtd_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh dtd_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh eurosat_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh eurosat_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh FGVCAircraft_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh FGVCAircraft_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh food101_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh food101_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh oxford_flowers_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh oxford_flowers_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh oxford_pets_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh ucf101_pl rn50 end 16 16 True 1insd_cc_loss_cliprn50_prosim

bash scripts/coopins/main_insd_clip_prosim.sh ucf101_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim
bash scripts/coopins/main_insd_clip_prosim.sh oxford_pets_pl rn50 end 16 16 False 1insd_cc_loss_cliprn50_prosim

