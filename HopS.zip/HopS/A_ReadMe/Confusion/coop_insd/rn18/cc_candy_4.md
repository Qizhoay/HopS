# Now:  eurosat_pl FGVCAircraft_pl food101_pl oxford_flowers_pl oxford_pets_pl ucf101_pl
bash scripts/coopins/main_insd_rn18_prosim.sh caltech101_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh caltech101_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim

bash scripts/coopins/main_insd_rn18_prosim.sh dtd_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh dtd_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim

bash scripts/coopins/main_insd_rn18_prosim.sh eurosat_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh eurosat_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim

bash scripts/coopins/main_insd_rn18_prosim.sh FGVCAircraft_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh food101_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh food101_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim

bash scripts/coopins/main_insd_rn18_prosim.sh oxford_flowers_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh oxford_flowers_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim

bash scripts/coopins/main_insd_rn18_prosim.sh oxford_pets_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim

bash scripts/coopins/main_insd_rn18_prosim.sh ucf101_pl rn50 end 16 16 True 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh oxford_pets_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh FGVCAircraft_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim
bash scripts/coopins/main_insd_rn18_prosim.sh ucf101_pl rn50 end 16 16 False 4insd_cc_loss_rn18_prosim
