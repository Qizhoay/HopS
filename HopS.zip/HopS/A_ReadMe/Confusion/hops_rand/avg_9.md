# Avg_c=9
bash scripts/hops/main.sh caltech101_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh caltech101_pl rn50_b16 end 16 16 True 9_ce_loss_b16
bash scripts/hops/main.sh caltech101_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh caltech101_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh caltech101_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh dtd_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh dtd_pl rn50_b16 end 16 16 True 9_ce_loss_b16

bash scripts/hops/main.sh dtd_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh dtd_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh dtd_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh eurosat_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh eurosat_pl rn50_b16 end 16 16 True 9_ce_loss_b16
bash scripts/hops/main.sh eurosat_pl rn50_b64 end 16 16 True 9_ce_loss_b64

bash scripts/hops/main.sh eurosat_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh eurosat_pl rn50_b256 end 16 16 True 9_ce_loss_b256
bash scripts/hops/main.sh FGVCAircraft_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh FGVCAircraft_pl rn50_b16 end 16 16 True 9_ce_loss_b16

bash scripts/hops/main.sh FGVCAircraft_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh FGVCAircraft_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh FGVCAircraft_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh food101_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh food101_pl rn50_b16 end 16 16 True 9_ce_loss_b16

bash scripts/hops/main.sh food101_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh food101_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh food101_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh oxford_flowers_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh oxford_flowers_pl rn50_b16 end 16 16 True 9_ce_loss_b16
bash scripts/hops/main.sh oxford_flowers_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh oxford_flowers_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh oxford_flowers_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh oxford_pets_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh oxford_pets_pl rn50_b16 end 16 16 True 9_ce_loss_b16
bash scripts/hops/main.sh oxford_pets_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh oxford_pets_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh oxford_pets_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh ucf101_pl rn50 end 16 16 True 9_ce_loss
bash scripts/hops/main.sh ucf101_pl rn50_b16 end 16 16 True 9_ce_loss_b16
bash scripts/hops/main.sh ucf101_pl rn50_b64 end 16 16 True 9_ce_loss_b64
bash scripts/hops/main.sh ucf101_pl rn50_b128 end 16 16 True 9_ce_loss_b128
bash scripts/hops/main.sh ucf101_pl rn50_b256 end 16 16 True 9_ce_loss_b256

bash scripts/hops/main.sh caltech101_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh caltech101_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh caltech101_pl rn50_b64 end 16 16 False 9_ce_loss_b64
bash scripts/hops/main.sh caltech101_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh caltech101_pl rn50_b256 end 16 16 False 9_ce_loss_b256

bash scripts/hops/main.sh dtd_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh dtd_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh dtd_pl rn50_b64 end 16 16 False 9_ce_loss_b64
bash scripts/hops/main.sh dtd_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh dtd_pl rn50_b256 end 16 16 False 9_ce_loss_b256

bash scripts/hops/main.sh eurosat_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh eurosat_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh eurosat_pl rn50_b64 end 16 16 False 9_ce_loss_b64
bash scripts/hops/main.sh eurosat_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh eurosat_pl rn50_b256 end 16 16 False 9_ce_loss_b256

bash scripts/hops/main.sh FGVCAircraft_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh FGVCAircraft_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh FGVCAircraft_pl rn50_b64 end 16 16 False 9_ce_loss_b64
# wait

bash scripts/hops/main.sh FGVCAircraft_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh FGVCAircraft_pl rn50_b256 end 16 16 False 9_ce_loss_b256
bash scripts/hops/main.sh food101_pl rn50 end 16 16 False 9_ce_loss

bash scripts/hops/main.sh food101_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh food101_pl rn50_b64 end 16 16 False 9_ce_loss_b64
bash scripts/hops/main.sh food101_pl rn50_b128 end 16 16 False 9_ce_loss_b128

bash scripts/hops/main.sh food101_pl rn50_b256 end 16 16 False 9_ce_loss_b256
bash scripts/hops/main.sh oxford_flowers_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh oxford_flowers_pl rn50_b16 end 16 16 False 9_ce_loss_b16

bash scripts/hops/main.sh oxford_flowers_pl rn50_b64 end 16 16 False 9_ce_loss_b64
bash scripts/hops/main.sh oxford_flowers_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh oxford_flowers_pl rn50_b256 end 16 16 False 9_ce_loss_b256

bash scripts/hops/main.sh oxford_pets_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh oxford_pets_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh oxford_pets_pl rn50_b64 end 16 16 False 9_ce_loss_b64

bash scripts/hops/main.sh oxford_pets_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh oxford_pets_pl rn50_b256 end 16 16 False 9_ce_loss_b256

bash scripts/hops/main.sh ucf101_pl rn50 end 16 16 False 9_ce_loss
bash scripts/hops/main.sh ucf101_pl rn50_b16 end 16 16 False 9_ce_loss_b16
bash scripts/hops/main.sh ucf101_pl rn50_b64 end 16 16 False 9_ce_loss_b64
bash scripts/hops/main.sh ucf101_pl rn50_b128 end 16 16 False 9_ce_loss_b128
bash scripts/hops/main.sh ucf101_pl rn50_b256 end 16 16 False 9_ce_loss_b256
