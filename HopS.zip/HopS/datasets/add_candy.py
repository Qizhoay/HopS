import random
import math
import numpy as np
import torch
import torch.nn.functional as F
import pandas as pd

import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import clip
import torch.nn as nn

def generate_fewshot_dataset_with_rand_candy(data_source, num_shots, avg_c, seed):
    if num_shots < 1:
        return data_source

    random.seed(seed)
    np.random.seed(seed)
    print(f"Creating a {num_shots}-shot dataset with {avg_c} confused labels in S")

    output = []

    # 存储每个标签对应的类别名称
    label_to_classname = {item.label: item.classname for item in data_source}
    print(f'label_to_classname: {label_to_classname}')

    # 获取所有类别标签和图片路径
    label_set = set()
    img_paths = []
    for item in data_source:
        label_set.add(item.label)
        img_paths.append(item.impath)
    img_paths = np.array(img_paths)
    num_classes = max(label_set) + 1

    # 创建从图像路径到索引的映射
    img_paths_dict = {k: v for v, k in enumerate(img_paths)}

    # 存储每个类别的图片路径
    label_imgpath_dict = {idx: [] for idx in label_set}
    for item in data_source:
        label_imgpath_dict[item.label].append(item.impath)

    rng = np.random.default_rng(seed=seed)

    # 记录每个类别已使用的错误标签
    used_error_labels_per_class = {i: set() for i in label_set}

    # 初始化标签转移矩阵
    transfer_matrix = np.zeros((num_classes, num_classes), dtype=int)

    for id in label_set:
        class_imgpaths = np.array(label_imgpath_dict[id])  # 该类别的所有图像路径
        if len(class_imgpaths) < num_shots:
            is_replace = True  # 样本数不够，允许重复选择
        else:
            is_replace = False

        # 随机选择 num_shots 张图片
        num_shots_array = rng.choice(len(class_imgpaths), size=num_shots, replace=is_replace)
        img_paths_class = class_imgpaths[num_shots_array]

        for img_path in img_paths_class:
            index = img_paths_dict[img_path]
            correct_label = id  # 真实标签
            candidate_labels = [correct_label]  # 确保正确类别在候选集中

            # 计算可以作为错误标签的类别（排除正确类别）
            remaining_labels = list(set(label_set) - {correct_label})

            # 获取未使用的错误标签
            available_error_labels = list(set(remaining_labels) - used_error_labels_per_class[correct_label])

            # 如果可选错误标签不足 avg_c，则允许重复选择
            if len(available_error_labels) < avg_c:
                additional_labels = random.choices(remaining_labels, k=avg_c - len(available_error_labels))
                available_error_labels += additional_labels

            # 采样 avg_c 个错误类别
            sampled_labels = random.sample(available_error_labels, avg_c) if len(available_error_labels) >= avg_c else available_error_labels
            candidate_labels.extend(sampled_labels)

            # 记录已使用的错误标签
            used_error_labels_per_class[correct_label].update(sampled_labels)

            # # 更新标签转移矩阵：统计候选集标签之间的共现关系
            # for i in range(len(sampled_labels)):
            #     for j in range(i, len(sampled_labels)):
            #         # 获取共现标签对的索引
            #         label1 = sampled_labels[i]
            #         label2 = sampled_labels[j]
                    
            #         # 在转移矩阵中相应位置加1，表示这两个标签共同出现
            #         transfer_matrix[label1, label2] += 1
            #         transfer_matrix[label2, label1] += 1  # 对称更新

            # 赋值数据
            data_source[index].labelset = candidate_labels
            data_source[index].classnameset = [label_to_classname[label] for label in candidate_labels]
            data_source[index]._label = tuple(candidate_labels)
            data_source[index]._classname = tuple([label_to_classname[label] for label in candidate_labels])
            data_source[index].true = correct_label

            output.append(data_source[index])

    # 输出调试信息
    for item in output:
        print(f'true: {item.true}, label: {item.labelset}, impath: {item.impath}, classname: {item.classname}')

    
    # transfer_matrix_df = pd.DataFrame(transfer_matrix, columns=range(num_classes), index=range(num_classes))
    
    # 存储标签转移矩阵到Excel文件
    # file_path = '/data1/zhaoyaqi/Yq23/250303_Coop/CoOp-final/data/S/label_transfer_matrix.xlsx'
    # transfer_matrix_df.to_excel(file_path)

    return output

def generate_fewshot_dataset_with_insd_candy(data_source, num_shots, avg_c, seed, device):
    if num_shots < 1:
        return data_source

    print(f"Creating a {num_shots}-shot dataset using ResNet-18 model-based soft label sampling with avg_c={avg_c}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    model = models.resnet18(pretrained=True)
    model = model.to(device)
    model.eval()

    # 预处理变换（必须！ImageNet预训练要求）
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),  # 0-1
        transforms.Normalize(mean=[0.485, 0.456, 0.406],  # ImageNet标准化
                             std=[0.229, 0.224, 0.225]),
    ])

    label_to_classname = {item.label: item.classname for item in data_source}
    label_set = set(item.label for item in data_source)
    num_classes = max(label_set) + 1

    label_img_dict = {label: [] for label in label_set}
    for item in data_source:
        label_img_dict[item.label].append(item)

    output = []

    for label in label_set:
        class_items = label_img_dict[label]
        if len(class_items) < num_shots:
            selected_items = np.random.choice(class_items, size=num_shots, replace=True)
        else:
            selected_items = np.random.choice(class_items, size=num_shots, replace=False)

        for item in selected_items:
            correct_label = item.label

            # 加载并预处理图像
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)

            with torch.no_grad():
                logits = model(img_tensor)  # (1, 1000)
                probs = F.softmax(logits, dim=1).squeeze(0)  # (1000)

                # 只保留数据集中存在的类别的概率
                relevant_probs = torch.zeros(num_classes, device=device)
                for cls in label_set:
                    relevant_probs[cls] = probs[cls]

                # 避免正确标签被选到干扰集合中
                relevant_probs[correct_label] = 0

                # 归一化扰动
                relevant_probs = relevant_probs / relevant_probs.max()
                relevant_probs = relevant_probs / relevant_probs.mean() * (avg_c / (num_classes - 1))
                relevant_probs = torch.clamp(relevant_probs, max=1.0)

                m = torch.distributions.binomial.Binomial(total_count=1, probs=relevant_probs)
                sampled_mask = m.sample().bool()
                wrong_labels = torch.where(sampled_mask)[0].tolist()

            # 保证数量：采够 avg_c-1 个干扰类
            if len(wrong_labels) < (avg_c - 1):
                # 不够的话，随机补充（从其他类别里选，排除掉 correct_label 和已有 wrong_labels）
                available = list(label_set - {correct_label} - set(wrong_labels))
                needed = (avg_c - 1) - len(wrong_labels)
                if len(available) >= needed:
                    additional = random.sample(available, needed)
                else:
                    # 极端情况：available也不够，放宽允许重复
                    additional = random.choices(list(label_set - {correct_label}), k=needed)
                wrong_labels += additional
            elif len(wrong_labels) > (avg_c - 1):
                # 太多了就随机下采样
                wrong_labels = random.sample(wrong_labels, avg_c - 1)

            # 最终的候选集合
            candidate_labels = [correct_label] + wrong_labels
            classnames = [label_to_classname[l] for l in candidate_labels]

            # 更新样本
            item.labelset = candidate_labels
            item.classnameset = classnames
            item._label = tuple(candidate_labels)
            item._classname = tuple(classnames)
            item.true = correct_label

            output.append(item)

    # 打印调试
    for item in output:
        print(f'true: {item.true}, labelset: {item.labelset}, path: {item.impath}')

    return output

def generate_fewshot_dataset_with_insd_rn50(data_source, num_shots, avg_c, seed, device):
    if num_shots < 1:
        return data_source

    print(f"Creating a {num_shots}-shot dataset using ResNet-50 model-based soft label sampling with avg_c={avg_c}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # 加载预训练的 ResNet-50 模型
    model = models.resnet50(pretrained=True)
    # model = models.resnet18(pretrained=True)
    model = model.to(device)
    model.eval()

    # 预处理变换（必须！ImageNet预训练要求）
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),  # 0-1
        transforms.Normalize(mean=[0.485, 0.456, 0.406],  # ImageNet标准化
                             std=[0.229, 0.224, 0.225]),
    ])

    label_to_classname = {item.label: item.classname for item in data_source}
    label_set = set(item.label for item in data_source)
    num_classes = max(label_set) + 1

    label_img_dict = {label: [] for label in label_set}
    for item in data_source:
        label_img_dict[item.label].append(item)

    output = []

    for label in label_set:
        class_items = label_img_dict[label]
        if len(class_items) < num_shots:
            selected_items = np.random.choice(class_items, size=num_shots, replace=True)
        else:
            selected_items = np.random.choice(class_items, size=num_shots, replace=False)

        for item in selected_items:
            correct_label = item.label

            # 加载并预处理图像
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)

            with torch.no_grad():
                logits = model(img_tensor)  # (1, 1000)
                probs = F.softmax(logits, dim=1).squeeze(0)  # (1000)

                # 只保留数据集中存在的类别的概率
                relevant_probs = torch.zeros(num_classes, device=device)
                for cls in label_set:
                    relevant_probs[cls] = probs[cls]

                # 避免正确标签被选到干扰集合中
                relevant_probs[correct_label] = 0

                # 归一化扰动
                relevant_probs = relevant_probs / relevant_probs.max()
                relevant_probs = relevant_probs / relevant_probs.mean() * (avg_c / (num_classes - 1))
                relevant_probs = torch.clamp(relevant_probs, max=1.0)

                m = torch.distributions.binomial.Binomial(total_count=1, probs=relevant_probs)
                sampled_mask = m.sample().bool()
                wrong_labels = torch.where(sampled_mask)[0].tolist()

            # 保证数量：采够 avg_c-1 个干扰类
            if len(wrong_labels) < (avg_c - 1):
                # 不够的话，随机补充（从其他类别里选，排除掉 correct_label 和已有 wrong_labels）
                available = list(label_set - {correct_label} - set(wrong_labels))
                needed = (avg_c - 1) - len(wrong_labels)
                if len(available) >= needed:
                    additional = random.sample(available, needed)
                else:
                    # 极端情况：available也不够，放宽允许重复
                    additional = random.choices(list(label_set - {correct_label}), k=needed)
                wrong_labels += additional
            elif len(wrong_labels) > (avg_c - 1):
                # 太多了就随机下采样
                wrong_labels = random.sample(wrong_labels, avg_c - 1)

            # 最终的候选集合
            candidate_labels = [correct_label] + wrong_labels
            classnames = [label_to_classname[l] for l in candidate_labels]

            # 更新样本
            item.labelset = candidate_labels
            item.classnameset = classnames
            item._label = tuple(candidate_labels)
            item._classname = tuple(classnames)
            item.true = correct_label

            output.append(item)

    # 打印调试
    for item in output:
        print(f'true: {item.true}, labelset: {item.labelset}, path: {item.impath}')

    return output

def generate_fewshot_dataset_with_clip_rn50(data_source, num_shots, avg_c, seed, device):
    if num_shots < 1:
        return data_source

    print(f"Creating a {num_shots}-shot dataset using CLIP-RN50 zero-shot label sampling with avg_c={avg_c}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # 加载 CLIP 的 ResNet-50 模型
    model, preprocess = clip.load("RN50", device=device)
    model.eval()

    label_to_classname = {item.label: item.classname for item in data_source}
    label_set = sorted(set(item.label for item in data_source))
    classname_set = [label_to_classname[i] for i in label_set]
    num_classes = len(classname_set)

    # 文本 prompt 编码
    prompts = [f"a photo of a {name}" for name in classname_set]
    with torch.no_grad():
        text_tokens = clip.tokenize(prompts).to(device)               # [C, 77]
        text_features = model.encode_text(text_tokens)               # [C, D]
        text_features = text_features / text_features.norm(dim=1, keepdim=True)

    label_img_dict = {label: [] for label in label_set}
    for item in data_source:
        label_img_dict[item.label].append(item)

    output = []

    for label in label_set:
        class_items = label_img_dict[label]
        if len(class_items) < num_shots:
            selected_items = np.random.choice(class_items, size=num_shots, replace=True)
        else:
            selected_items = np.random.choice(class_items, size=num_shots, replace=False)

        for item in selected_items:
            correct_label = item.label

            # 图像预处理并编码
            image = preprocess(Image.open(item.impath).convert('RGB')).unsqueeze(0).to(device)
            with torch.no_grad():
                image_feature = model.encode_image(image)            # [1, D]
                image_feature = image_feature / image_feature.norm(dim=1, keepdim=True)
                similarities = (image_feature @ text_features.T).squeeze(0)  # [C]

                # 排除正确类，选 top-k 候选类
                similarities[correct_label] = -1e4
                topk_sim, topk_idx = similarities.topk(avg_c)
                wrong_labels = topk_idx.tolist()

            candidate_labels = [correct_label] + wrong_labels
            classnames = [label_to_classname[l] for l in candidate_labels]

            item.labelset = candidate_labels
            item.classnameset = classnames
            item._label = tuple(candidate_labels)
            item._classname = tuple(classnames)
            item.true = correct_label

            output.append(item)

    # 调试输出
    for item in output:
        print(f'true: {item.true}, labelset: {item.labelset}, path: {item.impath}')

    return output

def generate_fewshot_dataset_with_r18_prosim(data_source, num_shots, avg_c, seed, device):
    if num_shots < 1:
        return data_source

    print(f"Creating a {num_shots}-shot dataset using ResNet-18 feature + prototype similarity with avg_c={avg_c}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # 加载 ResNet-18 并取出最后一层前的特征
    backbone = models.resnet18(pretrained=True)
    model = nn.Sequential(*list(backbone.children())[:-1])  # 去掉最后一层 fc 层
    model = model.to(device)
    model.eval()

    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])

    label_set = set(item.label for item in data_source)
    num_classes = max(label_set) + 1
    label_to_classname = {item.label: item.classname for item in data_source}

    label_img_dict = {label: [] for label in label_set}
    for item in data_source:
        label_img_dict[item.label].append(item)

    # Step 1: 提取每张图像的特征
    features = []
    labels = []
    with torch.no_grad():
        for item in data_source:
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)
            feat = model(img_tensor).squeeze()  # shape: [512]
            features.append(feat.cpu())
            labels.append(item.label)
    features = torch.stack(features)  # [N, 512]
    labels = torch.tensor(labels)     # [N]

    # Step 2: 计算每个类别的原型向量
    prototypes = []
    for cls in range(num_classes):
        cls_feats = features[labels == cls]
        proto = cls_feats.mean(dim=0)
        proto = F.normalize(proto, dim=0)
        prototypes.append(proto)
    prototypes = torch.stack(prototypes)  # [C, 512]

    # Step 3: 对每个样本选择最相似的候选标签
    output = []
    for label in label_set:
        class_items = label_img_dict[label]
        selected_items = np.random.choice(class_items, size=num_shots, replace=(len(class_items) < num_shots))

        for item in selected_items:
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)
            with torch.no_grad():
                feat = model(img_tensor).squeeze()
                feat = F.normalize(feat, dim=0)  # [512]

                # 相似度：与每个类别原型的余弦相似度
                sims = torch.matmul(prototypes.to(device), feat)  # [C]

                # 排除真实标签，从其余中选 top-(avg_c-1)
                sims[label] = -1e4
                topk = torch.topk(sims, avg_c - 1).indices.tolist()
                candidate_labels = [label] + topk
                classnames = [label_to_classname[l] for l in candidate_labels]

            # 更新样本
            item.labelset = candidate_labels
            item.classnameset = classnames
            item._label = tuple(candidate_labels)
            item._classname = tuple(classnames)
            item.true = label

            output.append(item)

    # 打印调试
    for item in output:
        print(f'true: {item.true}, labelset: {item.labelset}, path: {item.impath}')

    return output

def generate_fewshot_dataset_with_r50_prosim(data_source, num_shots, avg_c, seed, device):
    if num_shots < 1:
        return data_source

    print(f"Creating a {num_shots}-shot dataset using ResNet-50 feature + prototype similarity with avg_c={avg_c}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # 加载 ResNet-50 并取出最后一层前的特征
    backbone = models.resnet50(pretrained=True)
    model = nn.Sequential(*list(backbone.children())[:-1])  # 去掉最后一层 fc 层
    model = model.to(device)
    model.eval()

    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225]),
    ])

    label_set = set(item.label for item in data_source)
    num_classes = max(label_set) + 1
    label_to_classname = {item.label: item.classname for item in data_source}

    label_img_dict = {label: [] for label in label_set}
    for item in data_source:
        label_img_dict[item.label].append(item)

    # Step 1: 提取每张图像的特征
    features = []
    labels = []
    with torch.no_grad():
        for item in data_source:
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)
            feat = model(img_tensor).squeeze()  # shape: [512]
            features.append(feat.cpu())
            labels.append(item.label)
    features = torch.stack(features)  # [N, 512]
    labels = torch.tensor(labels)     # [N]

    # Step 2: 计算每个类别的原型向量
    prototypes = []
    for cls in range(num_classes):
        cls_feats = features[labels == cls]
        proto = cls_feats.mean(dim=0)
        proto = F.normalize(proto, dim=0)
        prototypes.append(proto)
    prototypes = torch.stack(prototypes)  # [C, 512]

    # Step 3: 对每个样本选择最相似的候选标签
    output = []
    for label in label_set:
        class_items = label_img_dict[label]
        selected_items = np.random.choice(class_items, size=num_shots, replace=(len(class_items) < num_shots))

        for item in selected_items:
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)
            with torch.no_grad():
                feat = model(img_tensor).squeeze()
                feat = F.normalize(feat, dim=0)  # [512]

                # 相似度：与每个类别原型的余弦相似度
                sims = torch.matmul(prototypes.to(device), feat)  # [C]

                # 排除真实标签，从其余中选 top-(avg_c-1)
                sims[label] = -1e4
                topk = torch.topk(sims, avg_c - 1).indices.tolist()
                candidate_labels = [label] + topk
                classnames = [label_to_classname[l] for l in candidate_labels]

            # 更新样本
            item.labelset = candidate_labels
            item.classnameset = classnames
            item._label = tuple(candidate_labels)
            item._classname = tuple(classnames)
            item.true = label

            output.append(item)

    # 打印调试
    for item in output:
        print(f'true: {item.true}, labelset: {item.labelset}, path: {item.impath}')

    return output

def generate_fewshot_dataset_with_clip_prosim(data_source, num_shots, avg_c, seed, device):
    if num_shots < 1:
        return data_source

    print(f"Creating a {num_shots}-shot dataset using CLIP-ResNet50 feature + prototype similarity with avg_c={avg_c}")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # 加载 CLIP 模型和对应的预处理
    model, preprocess = clip.load("RN50", device=device)
    model.eval()

    label_set = set(item.label for item in data_source)
    num_classes = max(label_set) + 1
    label_to_classname = {item.label: item.classname for item in data_source}

    label_img_dict = {label: [] for label in label_set}
    for item in data_source:
        label_img_dict[item.label].append(item)

    # Step 1: 提取每张图像的特征
    features = []
    labels = []
    with torch.no_grad():
        for item in data_source:
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)
            feat = model.encode_image(img_tensor).squeeze()  # shape: [1024]
            features.append(feat.cpu())
            labels.append(item.label)
    features = torch.stack(features)  # [N, 1024]
    labels = torch.tensor(labels)

    # Step 2: 计算每个类别的原型向量
    prototypes = []
    for cls in range(num_classes):
        cls_feats = features[labels == cls]
        proto = cls_feats.mean(dim=0)
        proto = F.normalize(proto.to(torch.float32), dim=0)
        prototypes.append(proto)
    prototypes = torch.stack(prototypes)  # [C, 1024]
    prototypes = prototypes.to(torch.float32)
    # Step 3: 为每个样本选择 avg_c + 1 个候选标签（包含真实标签）
    output = []
    for label in label_set:
        class_items = label_img_dict[label]
        selected_items = np.random.choice(class_items, size=num_shots, replace=(len(class_items) < num_shots))

        for item in selected_items:
            img = Image.open(item.impath).convert('RGB')
            img_tensor = preprocess(img).unsqueeze(0).to(device)
            with torch.no_grad():
                feat = model.encode_image(img_tensor).squeeze()  # [1024]
                feat = F.normalize(feat, dim=0)
                feat = feat.to(torch.float32)
                sims = torch.matmul(prototypes.to(device), feat.to(torch.float32))  # [C]
                sims[label] = -1e4
                topk = torch.topk(sims, avg_c).indices.tolist()
                candidate_labels = [label] + topk
                classnames = [label_to_classname[l] for l in candidate_labels]

            item.labelset = candidate_labels
            item.classnameset = classnames
            item._label = tuple(candidate_labels)
            item._classname = tuple(classnames)
            item.true = label

            output.append(item)

    for item in output:
        print(f'true: {item.true}, labelset: {item.labelset}, path: {item.impath}')

    return output