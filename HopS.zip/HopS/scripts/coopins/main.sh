#!/bin/bash

# custom config
DATA=.../HopS/data
TRAINER=CoOpIns

DATASET=$1
CFG=$2  # config file
CTP=$3  # class token position (end or middle)
NCTX=$4  # number of context tokens
SHOTS=$5  # number of shots (1, 2, 4, 8, 16)
CSC=$6  # class-specific context (False or True)
AVG_C=$7

# for SEED in 1
for SEED in 1 2 3
do
    # DIR=output/${DATASET}/${TRAINER}/${CFG}_${SHOTS}shots/nctx${NCTX}_csc${CSC}_ctp${CTP}/seed${SEED}
    DIR=output/${DATASET}/${TRAINER}/${CFG}_${SHOTS}shots/nctx${NCTX}_csc${CSC}_ctp${CTP}/avg_C${AVG_C}/seed${SEED}
    if [ -d "$DIR" ]; then
        # echo "Oops! The results exist at ${DIR} (so skip this job)"
        CUDA_VISIBLE_DEVICES=1 python train_coop_ins.py \
        --root ${DATA} \
        --seed ${SEED} \
        --trainer ${TRAINER} \
        --dataset-config-file configs/datasets/${DATASET}.yaml \
        --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
        --output-dir ${DIR} \
        TRAINER.CoOpIns.N_CTX ${NCTX} \
        TRAINER.CoOpIns.CSC ${CSC} \
        TRAINER.CoOpIns.CLASS_TOKEN_POSITION ${CTP} \
        DATASET.NUM_SHOTS ${SHOTS}
    else
        CUDA_VISIBLE_DEVICES=1 python train_coop_ins.py \
        --root ${DATA} \
        --seed ${SEED} \
        --trainer ${TRAINER} \
        --dataset-config-file configs/datasets/${DATASET}.yaml \
        --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
        --output-dir ${DIR} \
        TRAINER.CoOpIns.N_CTX ${NCTX} \
        TRAINER.CoOpIns.CSC ${CSC} \
        TRAINER.CoOpIns.CLASS_TOKEN_POSITION ${CTP} \
        DATASET.NUM_SHOTS ${SHOTS}
    fi
done